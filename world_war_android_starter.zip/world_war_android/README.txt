World War - Android starter project
This is a playable offline prototype, NOT a built APK.
Build with Buildozer on a supported Linux environment:
  buildozer -v android debug
The APK will be generated under bin/ if compilation succeeds.
Persian glyph rendering in Kivy may require a Persian-capable font and RTL shaping for correct display.
