[app]
title = World War
package.name = worldwar
package.domain = org.rezagames
source.dir = .
source.include_exts = py,png,jpg,kv
version = 0.1
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.api = 35
android.minapi = 23
[buildozer]
log_level = 2
warn_on_root = 1
