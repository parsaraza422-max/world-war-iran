from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
import random

COUNTRIES=['ایران','ترکیه','عراق','آلمان','فرانسه','ژاپن','چین','هند','برزیل','کانادا','مصر','روسیه']
class WorldWar(App):
 def build(self):
  self.money=10000; self.army=100; self.country='ایران'; self.turn=1
  self.root=BoxLayout(orientation='vertical',spacing=5,padding=8)
  self.info=Label(size_hint_y=.17,font_size='18sp')
  self.root.add_widget(self.info)
  self.log=Label(text='به بازی جنگ جهانی خوش آمدید',size_hint_y=.2)
  self.root.add_widget(self.log)
  scroll=ScrollView()
  grid=GridLayout(cols=2,spacing=6,size_hint_y=None)
  grid.bind(minimum_height=grid.setter('height'))
  for title,action in [('کشور بعدی',self.change),('توسعه اقتصاد',self.economy),('ساخت ارتش',self.recruit),('حمله شبیه‌سازی',self.attack),('تجارت',self.trade),('رویداد جدید',self.event),('نوبت بعد',self.next_turn),('وضعیت کشور',self.status)]:
   btn=Button(text=title,font_size='18sp',size_hint_y=None,height=65)
   btn.bind(on_press=action);grid.add_widget(btn)
  scroll.add_widget(grid);self.root.add_widget(scroll)
  self.status();return self.root
 def status(self,*args):
  self.info.text=f'{self.country} | نوبت {self.turn}\nبودجه: {self.money} | نیرو: {self.army}'
 def message(self,s):
  self.log.text=s;self.status()
 def change(self,*args):
  self.country=COUNTRIES[(COUNTRIES.index(self.country)+1)%len(COUNTRIES)];self.message('کشور انتخاب شد: '+self.country)
 def economy(self,*args):
  if self.money<500:self.message('بودجه کافی نیست');return
  self.money-=500;self.money+=random.randint(600,1300);self.message('اقتصاد کشور توسعه یافت')
 def recruit(self,*args):
  if self.money<300:self.message('بودجه کافی نیست');return
  self.money-=300;self.army+=20;self.message('۲۰ نیروی جدید آموزش دیدند')
 def attack(self,*args):
  if self.army<10:self.message('نیروی کافی ندارید');return
  target=random.choice([x for x in COUNTRIES if x!=self.country]);loss=random.randint(1,10);self.army-=loss
  self.message(f'🚀 عملیات فرضی علیه {target}\nنتیجه: {random.choice(["موفق","دفاع حریف موفق بود"])} | کاهش نیرو: {loss}')
 def trade(self,*args):
  gain=random.randint(100,600);self.money+=gain;self.message(f'تجارت انجام شد: {gain} بودجه')
 def event(self,*args):
  self.message(random.choice(['📰 توافق تجاری جدید','📰 مذاکرات صلح آغاز شد','📰 فناوری دفاعی پیشرفت کرد','📰 کمک‌های اقتصادی دریافت شد']))
 def next_turn(self,*args):
  self.turn+=1;self.money+=200;self.message('نوبت جدید؛ درآمد ۲۰۰ واحد')
WorldWar().run()
